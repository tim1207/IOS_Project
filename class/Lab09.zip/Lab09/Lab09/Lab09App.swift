//
//  Lab09App.swift
//  Lab09
//
//  Created by 林峻霆 on 2022/5/25.
//

import SwiftUI

@main
struct Lab09App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
