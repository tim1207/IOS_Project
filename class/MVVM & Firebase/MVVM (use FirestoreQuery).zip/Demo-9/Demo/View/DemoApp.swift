//
//  DemoApp.swift
//  Demo
//
//  Created by Peter Pan on 2022/5/11.
//

import SwiftUI
import Firebase

@main
struct DemoApp: App {
    
    init() {
        FirebaseApp.configure()
    }
    
    var body: some Scene {
        WindowGroup {
            SongList()
        }
    }
}
