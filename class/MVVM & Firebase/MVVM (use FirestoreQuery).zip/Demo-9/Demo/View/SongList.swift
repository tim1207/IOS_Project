//
//  SongList.swift
//  FirebaseSwiftUIDemo
//
//  Created by SHIH-YING PAN on 2021/5/10.
//

import SwiftUI
import FirebaseFirestore
import FirebaseFirestoreSwift

struct SongList: View {
    let songListViewModel = SongListViewModel()
    @FirestoreQuery(collectionPath: "songs") var songs: [Song]
    
    var body: some View {
        NavigationView {
            List{
                ForEach(songs) { song in
                    NavigationLink {
                        EditSongView(songListViewModel: songListViewModel, song: song)
                    } label: {
                        SongRow(song: song)
                    }
//                    舊版
//                    NavigationLink(destination: EditSongView(songListViewModel: songListViewModel, song: song)) {
//                        SongRow(song: song)
//                    }
                }
                .onDelete { indexSet in
                    if let index = indexSet.first {
                        let song = songs[index]
                        songListViewModel.deleteSong(song: song)
                    }
                }
            }
            .toolbar {
                NavigationLink {
                    EditSongView(songListViewModel: songListViewModel, song: nil)
                } label: {
                    Image(systemName: "plus")
                }
                
            }
        }
    }
}

struct SongList_Previews: PreviewProvider {
    static var previews: some View {
        SongList()
    }
}
