//
//  SongListViewModel.swift
//  FirebaseSwiftUIDemo
//
//  Created by SHIH-YING PAN on 2021/5/10.
//

import FirebaseFirestore

class SongListViewModel {
    private let store = Firestore.firestore()

    func modifySong(song: Song) {
        do {
            try store.collection("songs").document(song.id ?? "").setData(from: song)
        } catch  {
            print(error)
        }
    }
    
    func addSong(song: Song) {
        do {
            let documentReference = try store.collection("songs").addDocument(from: song)
            print(documentReference.documentID)
        } catch {
            print(error)
        }
    }
    
    func deleteSong(song: Song) {
        let documentReference = store.collection("songs").document(song.id ?? "")
        documentReference.delete()
    }
   
}
