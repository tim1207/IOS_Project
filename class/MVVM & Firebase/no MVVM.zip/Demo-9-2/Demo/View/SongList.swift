//
//  SongList.swift
//  FirebaseSwiftUIDemo
//
//  Created by SHIH-YING PAN on 2021/5/10.
//

import SwiftUI
import FirebaseFirestore
import FirebaseFirestoreSwift

struct SongList: View {
    @FirestoreQuery(collectionPath: "songs") var songs: [Song]
    
    var body: some View {
        NavigationView {
            List{
                ForEach(songs) { song in
                    NavigationLink {
                        EditSongView(song: song)
                    } label: {
                        SongRow(song: song)
                    }
//                    舊版
//                    NavigationLink(destination: EditSongView(songListViewModel: songListViewModel, song: song)) {
//                        SongRow(song: song)
//                    }
                }
                .onDelete { indexSet in
                    if let index = indexSet.first {
                        let song = songs[index]
                        deleteSong(song: song)
                    }
                }
            }
            .toolbar {
                NavigationLink {
                    EditSongView(song: nil)
                } label: {
                    Image(systemName: "plus")
                }
                
            }
        }
    }
    
    func deleteSong(song: Song) {
        let store = Firestore.firestore()
        let documentReference = store.collection("songs").document(song.id ?? "")
        documentReference.delete()
    }
}

struct SongList_Previews: PreviewProvider {
    static var previews: some View {
        SongList()
    }
}
