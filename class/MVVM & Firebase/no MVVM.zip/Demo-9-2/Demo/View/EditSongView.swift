//
//  EditSongView.swift
//  Demo
//
//  Created by Peter Pan on 2022/5/16.
//

import SwiftUI
import FirebaseFirestore

struct EditSongView: View {
    @State private var name = ""
    @State private var singer = ""
    @State private var rate = 1
    let song: Song?
    @Environment(\.dismiss) var dismiss
    // 舊版
    // @Environment(\.presentationMode) var presentationMode


    var body: some View {
        Form {
            TextField("name", text: $name)
                .onAppear(perform: {
                    if let song = song {
                        name = song.name
                        singer = song.singer
                        rate = song.rate
                    }
                })
            TextField("singer", text: $singer)
            Stepper("rate   \(rate)", value: $rate, in: 1...5)
        }
        .toolbar {
            Button("Save") {
                if var song = song {
                    song.name = name
                    song.singer = singer
                    song.rate = rate
                    modifySong(song: song)
                } else {
                    let song = Song(name: name, singer: singer, rate: rate)
                    addSong(song: song)
                }
               
                dismiss()
                // 舊版
                // presentationMode.wrappedValue.dismiss()

            }
        }
    }
    
    func addSong(song: Song) {
        do {
            let store = Firestore.firestore()
            let documentReference = try store.collection("songs").addDocument(from: song)
            print(documentReference.documentID)
        } catch {
            print(error)
        }
    }
    
    func modifySong(song: Song) {
        do {
            let store = Firestore.firestore()
            try store.collection("songs").document(song.id ?? "").setData(from: song)
        } catch  {
            print(error)
        }
    }
    
   
    
}

struct EditSongView_Previews: PreviewProvider {
    static var previews: some View {
        EditSongView(song: nil)
    }
}
