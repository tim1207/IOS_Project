//
//  Song.swift
//  Demo
//
//  Created by Peter Pan on 2022/5/11.
//

import FirebaseFirestoreSwift

struct Song: Codable, Identifiable {
    @DocumentID var id: String?
    var name: String
    var singer: String
    var rate: Int
}
