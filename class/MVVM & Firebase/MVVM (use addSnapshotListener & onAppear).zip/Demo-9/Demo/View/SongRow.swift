//
//  SongRow.swift
//  Demo
//
//  Created by Peter Pan on 2022/5/17.
//

import SwiftUI

struct SongRow: View {
    let song: Song
    var body: some View {
        HStack {
            Text(song.name)
            Spacer()
            VStack {
                Text(song.singer)
                Text("\(song.rate)")
            }
        }
    }
}

struct SongRow_Previews: PreviewProvider {
    static var previews: some View {
        SongRow(song: Song(name: "你好不好", singer: "周興哲", rate: 5))
    }
}
