//
//  SongListViewModel.swift
//  FirebaseSwiftUIDemo
//
//  Created by SHIH-YING PAN on 2021/5/10.
//

import FirebaseFirestore

class SongListViewModel: ObservableObject {
    private let store = Firestore.firestore()
    @Published var songs = [Song]()
    
    init() {
        listenChange()
    }
    
    func modifySong(song: Song) {
        do {
            try store.collection("songs").document(song.id ?? "").setData(from: song)
        } catch  {
            print(error)
        }
    }
    
    func addSong(song: Song) {
        do {
            let documentReference = try store.collection("songs").addDocument(from: song)
        } catch {
            print(error)
        }
    }
    
    func deleteSong(song: Song) {
        let documentReference = store.collection("songs").document(song.id ?? "")
        documentReference.delete()
    }
    
    func listenChange() {
        store.collection("songs").addSnapshotListener { snapshot, error in
            guard let snapshot = snapshot else { return }
            snapshot.documentChanges.forEach { documentChange in
                switch documentChange.type {
                case .added:
                    guard let song = try? documentChange.document.data(as: Song.self) else { break }
                    self.songs.append(song)
                case .modified:
                    guard let targetSong = try? documentChange.document.data(as: Song.self) else { break }
                    let index = self.songs.firstIndex { song in
                        song.id == targetSong.id
                    }
                    if let index = index {
                        self.songs[index] = targetSong
                    }
                case .removed:
                    guard let targetSong = try? documentChange.document.data(as: Song.self) else { break }
                    let index = self.songs.firstIndex { song in
                        song.id == targetSong.id
                    }
                    if let index = index {
                        self.songs.remove(at: index)

                    }
                }
            }
        }
    }
   
}
