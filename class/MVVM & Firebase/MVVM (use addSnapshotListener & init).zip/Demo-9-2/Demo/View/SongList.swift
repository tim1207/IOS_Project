//
//  SongList.swift
//  FirebaseSwiftUIDemo
//
//  Created by SHIH-YING PAN on 2021/5/10.
//

import SwiftUI
import FirebaseFirestore
import FirebaseFirestoreSwift

struct SongList: View {
    
    // 若想讓多個頁面存取，也可使用 EnvironmentObject
    @StateObject var songListViewModel = SongListViewModel()
    
    var body: some View {
        NavigationView {
            List{
                ForEach(songListViewModel.songs) { song in
                    NavigationLink {
                        EditSongView(songListViewModel: songListViewModel, song: song)
                    } label: {
                        SongRow(song: song)
                    }
//                    舊版
//                    NavigationLink(destination: EditSongView(songListViewModel: songListViewModel, song: song)) {
//                        SongRow(song: song)
//                    }
                }
                .onDelete { indexSet in
                    if let index = indexSet.first {
                        let song = songListViewModel.songs[index]
                        songListViewModel.deleteSong(song: song)
                    }
                }
            }
            .toolbar {
                NavigationLink {
                    EditSongView(songListViewModel: songListViewModel, song: nil)
                } label: {
                    Image(systemName: "plus")
                }
                
            }
        }
    }
}

struct SongList_Previews: PreviewProvider {
    static var previews: some View {
        SongList()
    }
}
